@echo off
title TV Dashboard
cd /d "%~dp0"
start "" "http://localhost:3000/tv"
npm start
