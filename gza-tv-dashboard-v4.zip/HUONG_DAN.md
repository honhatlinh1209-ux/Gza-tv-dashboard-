# TV Dashboard - Hướng dẫn cài đặt

## Yêu cầu
- Node.js (tải tại https://nodejs.org)
- PC và điện thoại cùng mạng WiFi

## Cài đặt

1. Giải nén thư mục `tv-dashboard` vào máy tính
2. Mở CMD/Terminal trong thư mục đó
3. Chạy lệnh:
   ```
   npm install
   npm start
   ```
4. Server sẽ hiện ra địa chỉ IP, ví dụ:
   ```
   📺 TV App  : http://192.168.1.10:3000/tv
   📱 Mobile  : http://192.168.1.10:3000
   ```

## Sử dụng

### TV (màn hình 2):
- Mở Chrome trên PC
- Truy cập: http://localhost:3000/tv
- Nhấn F11 để fullscreen
- Kéo cửa sổ Chrome sang màn hình TV

### Điện thoại (remote):
- Kết nối cùng WiFi với PC
- Mở trình duyệt trên ĐT
- Truy cập địa chỉ IP hiện trong CMD, ví dụ: http://192.168.1.10:3000
- Bắt đầu điều khiển!

## Tính năng
- 📊 Xem stats PC realtime (CPU, RAM, Uptime)
- 🎵 Điều khiển nhạc từ điện thoại
- 🚀 Mở app trên TV từ điện thoại
- 🔍 Tìm kiếm YouTube, phim từ điện thoại → hiện lên TV
- 📱 Remote điều hướng (D-pad, âm lượng)
- 💹 Giá vàng, tỷ giá USD, giá xăng
- 🌤️ Thời tiết
