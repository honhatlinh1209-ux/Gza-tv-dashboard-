"""
screen_wall.py — Bức tường ngăn chuột giữa 2 màn hình
Chạy: python screen_wall.py
Yêu cầu: pip install pystray pillow pywin32 keyboard
"""

import threading
import time
import sys
import ctypes
from ctypes import wintypes
import tkinter as tk
from tkinter import font as tkfont
import keyboard  # pip install keyboard
try:
    import pystray
    from PIL import Image, ImageDraw
    HAS_TRAY = True
except ImportError:
    HAS_TRAY = False

# ============================================================
# CONFIG — chỉnh theo setup của mày
# ============================================================
# Độ rộng màn hình PC (màn hình 1)
# Mày có thể xem trong Windows Settings > Display
PC_SCREEN_WIDTH = 1920   # thay bằng độ rộng màn hình PC của mày

# Hotkey mở/khóa bức tường
HOTKEY = 'ctrl+alt+t'

# Tự động khóa lại sau X giây khi mở khóa (0 = không tự khóa)
AUTO_LOCK_SECONDS = 8
# ============================================================

# Windows API
user32 = ctypes.windll.user32

class ScreenWall:
    def __init__(self):
        self.locked = True          # Bắt đầu trong trạng thái KHÓA
        self.auto_lock_timer = None
        self.running = True
        self.last_x = 0             # Vị trí chuột lần cuối trên PC
        self._hook = None

        # Lấy thông tin màn hình
        self.pc_width = PC_SCREEN_WIDTH
        self.boundary = PC_SCREEN_WIDTH - 2  # Biên giới ngay sát mép phải màn hình PC

        print(f"[Wall] PC width: {self.pc_width}px")
        print(f"[Wall] Boundary: x={self.boundary}px")
        print(f"[Wall] Hotkey: {HOTKEY}")
        print(f"[Wall] Auto-lock: {AUTO_LOCK_SECONDS}s" if AUTO_LOCK_SECONDS > 0 else "[Wall] Auto-lock: OFF")

    def get_cursor_pos(self):
        pt = wintypes.POINT()
        user32.GetCursorPos(ctypes.byref(pt))
        return pt.x, pt.y

    def set_cursor_pos(self, x, y):
        user32.SetCursorPos(x, y)

    def lock(self):
        self.locked = True
        if self.auto_lock_timer:
            self.auto_lock_timer.cancel()
            self.auto_lock_timer = None
        print("[Wall] 🧱 KHÓA — chuột bị chặn tại biên giới")
        self.notify_overlay("🧱 Đã khóa màn hình TV")

    def unlock(self):
        self.locked = False
        print(f"[Wall] 🔓 MỞ KHÓA — chuột tự do qua TV ({AUTO_LOCK_SECONDS}s)")
        self.notify_overlay(f"🔓 Mở khóa {AUTO_LOCK_SECONDS}s")

        # Tự động khóa lại
        if AUTO_LOCK_SECONDS > 0:
            self.auto_lock_timer = threading.Timer(AUTO_LOCK_SECONDS, self.lock)
            self.auto_lock_timer.daemon = True
            self.auto_lock_timer.start()

    def toggle(self):
        if self.locked:
            self.unlock()
        else:
            self.lock()

    def notify_overlay(self, msg):
        """Hiện thông báo nhỏ trên màn hình PC"""
        try:
            overlay = OverlayNotification(msg)
            t = threading.Thread(target=overlay.show, daemon=True)
            t.start()
        except Exception as e:
            print(f"[Wall] Overlay error: {e}")

    def watch_cursor(self):
        """Vòng lặp kiểm tra và chặn chuột"""
        while self.running:
            if self.locked:
                x, y = self.get_cursor_pos()
                # Nếu chuột tràn sang màn hình 2 (TV)
                if x >= self.boundary:
                    # Đẩy chuột lại màn hình PC
                    self.set_cursor_pos(self.boundary - 10, y)
            time.sleep(0.005)  # 200 lần/giây — đủ mượt, không tốn CPU

    def start(self):
        # Đăng ký hotkey
        keyboard.add_hotkey(HOTKEY, self.toggle)
        print(f"[Wall] ✅ Đang chạy! Nhấn {HOTKEY} để mở/khóa")

        # Chạy vòng lặp chuột trong thread riêng
        watch_thread = threading.Thread(target=self.watch_cursor, daemon=True)
        watch_thread.start()

        # Tray icon
        if HAS_TRAY:
            self.start_tray()
        else:
            print("[Wall] (Cài pystray để có tray icon: pip install pystray pillow)")
            # Giữ chương trình chạy
            try:
                while self.running:
                    time.sleep(0.5)
            except KeyboardInterrupt:
                self.stop()

    def start_tray(self):
        def make_icon(locked):
            img = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
            d = ImageDraw.Draw(img)
            if locked:
                # Vẽ khóa
                d.rectangle([20, 30, 44, 52], fill=(220, 80, 80, 255))
                d.arc([18, 15, 46, 40], start=0, end=180, fill=(220, 80, 80, 255), width=5)
                d.rectangle([28, 37, 36, 47], fill=(255, 255, 255, 200))
            else:
                # Vẽ mở khóa
                d.rectangle([20, 30, 44, 52], fill=(80, 200, 80, 255))
                d.arc([18, 10, 46, 35], start=0, end=180, fill=(80, 200, 80, 255), width=5)
                d.rectangle([28, 37, 36, 47], fill=(255, 255, 255, 200))
            return img

        def get_title():
            return f"Screen Wall — {'🧱 KHÓA' if self.locked else '🔓 MỞ'}"

        def on_toggle(icon, item):
            self.toggle()
            icon.icon = make_icon(self.locked)
            icon.title = get_title()

        def on_quit(icon, item):
            self.stop()
            icon.stop()

        menu = pystray.Menu(
            pystray.MenuItem(lambda text, item: f"{'🧱 Đang khóa' if self.locked else '🔓 Đang mở'}", None, enabled=False),
            pystray.MenuItem(f"Toggle ({HOTKEY})", on_toggle),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Thoát", on_quit),
        )

        self.tray_icon = pystray.Icon(
            "screen_wall",
            make_icon(self.locked),
            get_title(),
            menu
        )

        # Cập nhật icon khi trạng thái thay đổi
        orig_lock = self.lock
        orig_unlock = self.unlock
        def lock_with_icon():
            orig_lock()
            try:
                self.tray_icon.icon = make_icon(True)
                self.tray_icon.title = "Screen Wall — 🧱 KHÓA"
            except: pass
        def unlock_with_icon():
            orig_unlock()
            try:
                self.tray_icon.icon = make_icon(False)
                self.tray_icon.title = "Screen Wall — 🔓 MỞ"
            except: pass
        self.lock = lock_with_icon
        self.unlock = unlock_with_icon

        print("[Wall] Tray icon đã sẵn sàng!")
        self.tray_icon.run()

    def stop(self):
        self.running = False
        keyboard.unhook_all()
        print("[Wall] Đã dừng.")


class OverlayNotification:
    """Thông báo nổi nhỏ trên màn hình PC"""
    def __init__(self, message):
        self.message = message

    def show(self):
        try:
            root = tk.Tk()
            root.overrideredirect(True)      # Không có titlebar
            root.attributes('-topmost', True)
            root.attributes('-alpha', 0.0)

            # Style
            bg = '#1a1a2e'
            fg = '#ffffff'

            frame = tk.Frame(root, bg=bg, padx=20, pady=12)
            frame.pack()

            lbl = tk.Label(
                frame,
                text=self.message,
                font=('Segoe UI', 13, 'bold'),
                bg=bg, fg=fg
            )
            lbl.pack()

            # Đặt vị trí góc dưới bên trái màn hình PC
            root.update_idletasks()
            w = root.winfo_reqwidth()
            h = root.winfo_reqheight()
            x = 24
            y = root.winfo_screenheight() - h - 80
            root.geometry(f'+{x}+{y}')

            # Fade in
            def fade_in(alpha=0.0):
                alpha = min(alpha + 0.08, 0.92)
                root.attributes('-alpha', alpha)
                if alpha < 0.92:
                    root.after(20, lambda: fade_in(alpha))
                else:
                    root.after(1600, fade_out)

            # Fade out
            def fade_out(alpha=0.92):
                alpha = max(alpha - 0.08, 0.0)
                root.attributes('-alpha', alpha)
                if alpha > 0:
                    root.after(20, lambda: fade_out(alpha))
                else:
                    root.destroy()

            root.after(10, fade_in)
            root.mainloop()
        except Exception as e:
            pass


if __name__ == '__main__':
    print("=" * 45)
    print("  🧱 SCREEN WALL — Bức tường 2 màn hình")
    print("=" * 45)

    # Kiểm tra dependencies
    missing = []
    try: import keyboard
    except: missing.append('keyboard')
    try: import pystray
    except: missing.append('pystray')
    try: from PIL import Image
    except: missing.append('Pillow')
    try: import win32api
    except: missing.append('pywin32')

    if missing:
        print(f"\n⚠️  Thiếu thư viện: {', '.join(missing)}")
        print(f"Cài bằng lệnh:")
        print(f"  pip install {' '.join(missing)}\n")

    wall = ScreenWall()
    wall.start()
