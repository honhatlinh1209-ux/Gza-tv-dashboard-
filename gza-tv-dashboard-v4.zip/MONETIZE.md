# 💰 Hướng dẫn bán TV Dashboard — GZA System

## Kiến trúc tổng quan

```
[NGƯỜI MUA]              [SERVER CỦA MÀY]         [MÁY KHÁCH]
   Mua key          →    License Server            TV Dashboard
   (Telegram/website)    (VPS / máy mày)           (máy của họ)
                              ↕ validate
                         licenses.json
```

---

## BƯỚC 1 — Chạy License Server trên VPS (hoặc máy chính)

### Option A: Dùng VPS (khuyên dùng để bán thật)

```bash
# SSH vào VPS, cài Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Clone project lên VPS
scp -r tv-dashboard user@VPS_IP:~/
cd ~/tv-dashboard

# Cài deps
npm install

# Chạy license server (cổng 4000)
ADMIN_SECRET=mat-khau-manh-cua-may node license-server/license-server.js

# Hoặc dùng PM2 để chạy nền
npm install -g pm2
pm2 start license-server/license-server.js --name "gza-license"
pm2 save && pm2 startup
```

### Option B: Dùng máy PC mày (nhà mạng phải có IP tĩnh hoặc dùng ngrok)

```bash
# Chạy license server
node license-server/license-server.js

# Dùng ngrok để expose ra ngoài (free):
ngrok http 4000
# → copy URL kiểu https://abc123.ngrok.io → đây là LICENSE_SERVER
```

---

## BƯỚC 2 — Sửa config trong package bán ra

Khi đóng gói bán cho khách, sửa file `server/server.js`:

```js
// Dòng này — đổi thành URL license server của mày
const LICENSE_SERVER = 'https://YOUR_VPS_IP:4000';
// Ví dụ:
const LICENSE_SERVER = 'http://103.57.220.15:4000';
```

---

## BƯỚC 3 — Mở Admin Panel để tạo key

Mở trình duyệt vào:
```
http://YOUR_VPS_IP:4000/admin.html
```
(copy file `license-server/admin.html` lên thư mục `license-server/` trên VPS)

Serve file admin bằng cách thêm dòng này vào `license-server.js`:
```js
app.use(express.static(__dirname)); // đã có sẵn — admin.html tự được serve
```

---

## BƯỚC 4 — Quy trình bán key

### Khách mua key:
1. Khách nhắn Zalo/Telegram/website → báo muốn mua
2. Mày nhận tiền (Momo/banking)
3. Mở Admin Panel → **Tạo key** (điền tên khách làm ghi chú)
4. Copy key → gửi cho khách qua tin nhắn

### Khách kích hoạt:
1. Tải `tv-dashboard.zip` về → giải nén
2. Chạy `npm install && npm start`
3. Mở `http://localhost:3000` → nhập key → bấm Kích hoạt
4. Tự động vào TV Dashboard

---

## BƯỚC 5 — Giá bán & chiến lược

| Gói | Giá gợi ý | Thời hạn |
|-----|-----------|----------|
| Cơ bản | 99.000đ | 365 ngày |
| Trọn đời | 249.000đ | 9999 ngày |
| Family (2 PC) | 159.000đ | 365 ngày × 2 key |

Khi tạo key trọn đời:
```
POST /admin/generate
{ "days": 9999, "note": "Trọn đời - Nguyễn A" }
```

---

## Admin API — dùng bằng curl hoặc Postman

```bash
# Tạo 1 key 365 ngày
curl -X POST http://YOUR_VPS:4000/admin/generate \
  -H "Content-Type: application/json" \
  -H "X-Admin-Secret: mat-khau-manh-cua-may" \
  -d '{"count":1,"days":365,"note":"Khách Zalo 0909..."}'

# Xem toàn bộ key
curl http://YOUR_VPS:4000/admin/keys \
  -H "X-Admin-Secret: mat-khau-manh-cua-may"

# Thu hồi key
curl -X POST http://YOUR_VPS:4000/admin/revoke \
  -H "Content-Type: application/json" \
  -H "X-Admin-Secret: mat-khau-manh-cua-may" \
  -d '{"key":"ABCD-EFGH-IJKL-MNOP"}'

# Gia hạn thêm 365 ngày
curl -X POST http://YOUR_VPS:4000/admin/extend \
  -H "Content-Type: application/json" \
  -H "X-Admin-Secret: mat-khau-manh-cua-may" \
  -d '{"key":"ABCD-EFGH-IJKL-MNOP","days":365}'
```

---

## Bảo mật

- Đổi `ADMIN_SECRET` trong `license-server.js` thành password mạnh
- Chạy license server sau Nginx/Cloudflare để ẩn IP VPS
- Backup `licenses.json` hàng ngày (đây là DB của mày)
- Không chia sẻ file `licenses.json` với ai

---

## Các file quan trọng

| File | Mục đích |
|------|----------|
| `license-server/license-server.js` | Server xác thực key — chạy trên VPS |
| `license-server/admin.html` | Giao diện quản lý key — chỉ mày dùng |
| `license-server/licenses.json` | Database tất cả key (tự tạo khi có key đầu tiên) |
| `server/server.js` | TV Dashboard server — phân phối cho khách |
| `tv-app/activate.html` | Trang kích hoạt — khách nhập key tại đây |
| `.license` | Cache license trên máy khách (tự tạo) |
| `.machine_id` | ID máy của khách (tự tạo) |
