@echo off
title GZA TV Dashboard
cd /d "%~dp0"
color 0A

echo.
echo  ==========================================
echo   GZA TV DASHBOARD - Dang khoi dong...
echo  ==========================================
echo.

:: Kiem tra Node.js da cai chua
node -v >nul 2>&1
if errorlevel 1 (
    echo  [!] Chua co Node.js! Dang mo trang tai ve...
    echo  [!] Tai Node.js tai: https://nodejs.org
    echo  [!] Chon phien ban LTS, cai xong chay lai file nay.
    start "" "https://nodejs.org/en/download"
    pause
    exit /b 1
)

echo  [OK] Da co Node.js

:: Cai npm packages neu chua co
if not exist "server\node_modules" (
    echo  [..] Lan dau chay - dang cai packages, cho 1 phut...
    cd server
    call npm install --silent
    cd ..
    echo  [OK] Cai xong!
) else (
    echo  [OK] Packages da san sang
)

:: Mo trinh duyet sau 3 giay de server kip chay
echo  [..] Dang khoi dong server...
start "" /min cmd /c "timeout /t 3 /nobreak >nul & start "" http://localhost:3000/tv"

echo  [OK] Xong! TV Dashboard dang chay.
echo.
echo  TV  : http://localhost:3000/tv
echo  DT  : mo QR tren TV de ket noi
echo.
echo  Giu cua so nay mo khi dang dung. Dong cua so = tat server.
echo  ==========================================
echo.

cd server
node server.js
