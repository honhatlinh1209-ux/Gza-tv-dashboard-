/**
 * license-server.js
 * Server quản lý license key cho TV Dashboard
 * Chạy riêng, cổng 4000
 *
 * Cách dùng:
 *   node license-server.js
 *
 * Admin API (chỉ từ localhost hoặc dùng ADMIN_SECRET):
 *   POST /admin/generate   — tạo key mới
 *   GET  /admin/keys       — danh sách tất cả key
 *   POST /admin/revoke     — thu hồi key
 *
 * Client API (app gọi khi khởi động):
 *   POST /api/activate     — kích hoạt key lần đầu
 *   POST /api/validate     — kiểm tra key còn hạn không
 */

const express = require('express');
const crypto  = require('crypto');
const fs      = require('fs');
const path    = require('path');
const os      = require('os');

const app  = express();
app.use(express.json());

// ──────────────────────────────────────────────
// CONFIG — SỬA Ở ĐÂY
// ──────────────────────────────────────────────
const PORT          = 4000;
const ADMIN_SECRET  = process.env.ADMIN_SECRET || 'gza-admin-2024';   // đổi thành password mạnh hơn
const DB_FILE       = path.join(__dirname, 'licenses.json');
const LICENSE_DAYS  = 365;   // bao nhiêu ngày 1 key
// ──────────────────────────────────────────────

// ── DB đơn giản dùng JSON file ──────────────────
function loadDB() {
  if (!fs.existsSync(DB_FILE)) return { keys: {} };
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}
function saveDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// ── Tạo key dạng XXXX-XXXX-XXXX-XXXX ───────────
function generateKey() {
  const seg = () => crypto.randomBytes(2).toString('hex').toUpperCase();
  return `${seg()}-${seg()}-${seg()}-${seg()}`;
}

// ── Middleware kiểm tra admin secret ────────────
function requireAdmin(req, res, next) {
  const secret = req.headers['x-admin-secret'] || req.query.secret;
  if (secret !== ADMIN_SECRET) {
    return res.status(403).json({ error: 'Không có quyền admin' });
  }
  next();
}

// ── Lấy IP client ───────────────────────────────
function getClientIP(req) {
  return req.headers['x-forwarded-for']?.split(',')[0] || req.socket.remoteAddress || 'unknown';
}

// ════════════════════════════════════════════════
// ADMIN APIs
// ════════════════════════════════════════════════

// POST /admin/generate — tạo key mới
app.post('/admin/generate', requireAdmin, (req, res) => {
  const { note = '', count = 1, days = LICENSE_DAYS } = req.body;
  const db   = loadDB();
  const keys = [];

  for (let i = 0; i < Math.min(count, 50); i++) {
    let key;
    do { key = generateKey(); } while (db.keys[key]);

    db.keys[key] = {
      key,
      note,
      days,
      created_at : new Date().toISOString(),
      activated  : false,
      activated_at: null,
      expires_at : null,
      machine_id : null,
      revoked    : false,
    };
    keys.push(key);
  }

  saveDB(db);
  console.log(`[Admin] Tạo ${keys.length} key — ${note}`);
  res.json({ success: true, keys });
});

// GET /admin/keys — xem toàn bộ key
app.get('/admin/keys', requireAdmin, (req, res) => {
  const db   = loadDB();
  const list = Object.values(db.keys).map(k => ({
    ...k,
    status: k.revoked ? 'revoked'
          : !k.activated ? 'unused'
          : new Date(k.expires_at) < new Date() ? 'expired'
          : 'active',
  }));
  res.json({ total: list.length, keys: list });
});

// POST /admin/revoke — thu hồi key
app.post('/admin/revoke', requireAdmin, (req, res) => {
  const { key } = req.body;
  const db = loadDB();
  if (!db.keys[key]) return res.status(404).json({ error: 'Key không tồn tại' });
  db.keys[key].revoked = true;
  db.keys[key].revoked_at = new Date().toISOString();
  saveDB(db);
  res.json({ success: true, message: `Key ${key} đã bị thu hồi` });
});

// POST /admin/extend — gia hạn key thêm N ngày
app.post('/admin/extend', requireAdmin, (req, res) => {
  const { key, days = 365 } = req.body;
  const db = loadDB();
  if (!db.keys[key]) return res.status(404).json({ error: 'Key không tồn tại' });

  const rec = db.keys[key];
  const base = rec.expires_at ? new Date(rec.expires_at) : new Date();
  base.setDate(base.getDate() + days);
  rec.expires_at = base.toISOString();
  rec.revoked = false;
  saveDB(db);
  res.json({ success: true, expires_at: rec.expires_at });
});

// ════════════════════════════════════════════════
// CLIENT APIs — app gọi khi khởi động
// ════════════════════════════════════════════════

// POST /api/activate — kích hoạt key lần đầu
//   body: { key, machine_id }
app.post('/api/activate', (req, res) => {
  const { key, machine_id } = req.body;
  if (!key || !machine_id) return res.status(400).json({ valid: false, error: 'Thiếu key hoặc machine_id' });

  const db  = loadDB();
  const rec = db.keys[key];

  if (!rec)         return res.json({ valid: false, error: 'Key không hợp lệ' });
  if (rec.revoked)  return res.json({ valid: false, error: 'Key đã bị thu hồi' });
  if (rec.activated && rec.machine_id !== machine_id)
                    return res.json({ valid: false, error: 'Key đã được dùng trên máy khác' });

  const now     = new Date();
  const expires = new Date(now);
  expires.setDate(expires.getDate() + (rec.days || LICENSE_DAYS));

  rec.activated    = true;
  rec.activated_at = now.toISOString();
  rec.expires_at   = expires.toISOString();
  rec.machine_id   = machine_id;
  rec.last_seen    = now.toISOString();
  rec.ip           = getClientIP(req);
  saveDB(db);

  console.log(`[Activate] Key ${key} — machine ${machine_id} — expires ${expires.toLocaleDateString('vi-VN')}`);
  res.json({
    valid     : true,
    expires_at: expires.toISOString(),
    days_left : rec.days || LICENSE_DAYS,
    message   : `Kích hoạt thành công! Hạn dùng đến ${expires.toLocaleDateString('vi-VN')}`,
  });
});

// POST /api/validate — kiểm tra key hàng ngày
//   body: { key, machine_id }
app.post('/api/validate', (req, res) => {
  const { key, machine_id } = req.body;
  if (!key) return res.status(400).json({ valid: false, error: 'Thiếu key' });

  const db  = loadDB();
  const rec = db.keys[key];

  if (!rec)           return res.json({ valid: false, error: 'Key không hợp lệ' });
  if (rec.revoked)    return res.json({ valid: false, error: 'Key đã bị thu hồi' });
  if (!rec.activated) return res.json({ valid: false, error: 'Key chưa được kích hoạt' });
  if (rec.machine_id && rec.machine_id !== machine_id)
                      return res.json({ valid: false, error: 'Key không khớp với máy này' });

  const now     = new Date();
  const expires = new Date(rec.expires_at);
  const msLeft  = expires - now;
  const daysLeft = Math.ceil(msLeft / 86400000);

  if (msLeft < 0) return res.json({ valid: false, error: 'License đã hết hạn', expired: true });

  // Cập nhật last_seen
  rec.last_seen = now.toISOString();
  saveDB(db);

  res.json({
    valid     : true,
    expires_at: rec.expires_at,
    days_left : daysLeft,
    message   : daysLeft <= 30 ? `⚠️ License hết hạn sau ${daysLeft} ngày!` : 'OK',
  });
});

// ── Status page ─────────────────────────────────
app.get('/', (req, res) => {
  const db    = loadDB();
  const total = Object.keys(db.keys).length;
  const active = Object.values(db.keys).filter(k =>
    k.activated && !k.revoked && new Date(k.expires_at) > new Date()
  ).length;
  res.json({ service: 'TV Dashboard License Server', total_keys: total, active_licenses: active });
});

app.listen(PORT, '0.0.0.0', () => {
  const ip = Object.values(os.networkInterfaces())
    .flat().find(i => i.family === 'IPv4' && !i.internal)?.address || 'localhost';
  console.log('\n╔═════════════════════════════════════╗');
  console.log('║    LICENSE SERVER — TV Dashboard     ║');
  console.log('╠═════════════════════════════════════╣');
  console.log(`║  URL    : http://${ip}:${PORT}`);
  console.log(`║  Admin  : X-Admin-Secret: ${ADMIN_SECRET}`);
  console.log('╠═════════════════════════════════════╣');
  console.log('║  POST /admin/generate  — tạo key    ║');
  console.log('║  GET  /admin/keys      — xem key    ║');
  console.log('║  POST /api/activate    — kích hoạt ║');
  console.log('║  POST /api/validate    — check key  ║');
  console.log('╚═════════════════════════════════════╝\n');
});
