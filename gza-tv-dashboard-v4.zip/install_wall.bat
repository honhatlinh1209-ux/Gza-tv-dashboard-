@echo off
echo =====================================
echo   Cai dat Screen Wall dependencies
echo =====================================
echo.
pip install keyboard pystray Pillow pywin32
echo.
echo =====================================
echo   Xong! Chay bang lenh:
echo   python screen_wall.py
echo =====================================
pause
