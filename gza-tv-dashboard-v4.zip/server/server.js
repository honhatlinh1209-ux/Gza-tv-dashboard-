const express = require('express');
const { WebSocketServer } = require('ws');
const http = require('http');
const os   = require('os');
const path = require('path');
const fs   = require('fs');
const crypto = require('crypto');

const app    = express();
const server = http.createServer(app);
const wss    = new WebSocketServer({ server });

app.use(express.json());
app.use(express.static(path.join(__dirname, '../mobile')));
app.use('/tv', express.static(path.join(__dirname, '../tv-app')));

// ──────────────────────────────────────────────
// LICENSE CONFIG — SỬA Ở ĐÂY
// ──────────────────────────────────────────────
// URL của license server (chạy license-server.js ở đâu)
const LICENSE_SERVER = process.env.LICENSE_SERVER || 'http://localhost:4000';

// File lưu license key trên máy user
const LICENSE_FILE   = path.join(__dirname, '../.license');

// Tắt check license nếu muốn test (đổi thành true)
const SKIP_LICENSE   = process.env.SKIP_LICENSE === '1' || false;
// ──────────────────────────────────────────────

// ── Machine ID (unique per PC) ─────────────────
function getMachineID() {
  const id_file = path.join(__dirname, '../.machine_id');
  if (fs.existsSync(id_file)) return fs.readFileSync(id_file, 'utf8').trim();
  const id = crypto.randomUUID().replace(/-/g, '');
  fs.writeFileSync(id_file, id);
  return id;
}

// ── Load saved license ─────────────────────────
function loadSavedLicense() {
  try {
    if (!fs.existsSync(LICENSE_FILE)) return null;
    return JSON.parse(fs.readFileSync(LICENSE_FILE, 'utf8'));
  } catch { return null; }
}

function saveLicense(data) {
  fs.writeFileSync(LICENSE_FILE, JSON.stringify(data, null, 2));
}

// ── Validate license với server ────────────────
async function validateLicense(key, machine_id) {
  try {
    const res = await fetch(`${LICENSE_SERVER}/api/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key, machine_id }),
    });
    return await res.json();
  } catch(e) {
    // Nếu không kết nối được server → dùng offline grace period
    return { valid: null, offline: true, error: e.message };
  }
}

async function activateLicense(key, machine_id) {
  try {
    const res = await fetch(`${LICENSE_SERVER}/api/activate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key, machine_id }),
    });
    return await res.json();
  } catch(e) {
    return { valid: false, error: 'Không kết nối được License Server: ' + e.message };
  }
}

// ── License state ──────────────────────────────
let licenseState = {
  valid     : false,
  key       : null,
  expires_at: null,
  days_left : null,
  message   : '',
  checked_at: null,
};

async function checkLicense() {
  if (SKIP_LICENSE) {
    licenseState = { valid: true, key: 'DEV-MODE', expires_at: null, days_left: 999, message: 'Dev mode' };
    return;
  }

  const machine_id = getMachineID();
  const saved      = loadSavedLicense();

  if (!saved?.key) {
    licenseState = { valid: false, key: null, message: 'Chưa kích hoạt license' };
    return;
  }

  const result = await validateLicense(saved.key, machine_id);

  if (result.offline) {
    // Offline: dùng cache, cho phép 7 ngày grace
    if (saved.expires_at) {
      const diff = new Date(saved.expires_at) - new Date();
      const daysLeft = Math.ceil(diff / 86400000);
      if (daysLeft > 0) {
        licenseState = {
          valid     : true,
          key       : saved.key,
          expires_at: saved.expires_at,
          days_left : daysLeft,
          message   : '⚠️ Offline — dùng cache',
          offline   : true,
        };
        return;
      }
    }
    licenseState = { valid: false, key: saved.key, message: 'License server offline & cache hết hạn' };
    return;
  }

  if (result.valid) {
    licenseState = {
      valid     : true,
      key       : saved.key,
      expires_at: result.expires_at,
      days_left : result.days_left,
      message   : result.message || 'OK',
      checked_at: new Date().toISOString(),
    };
    // Cập nhật cache
    saveLicense({ key: saved.key, expires_at: result.expires_at });
  } else {
    licenseState = { valid: false, key: saved.key, message: result.error || 'License không hợp lệ' };
  }
}

// ── Utility ────────────────────────────────────
function getLocalIP() {
  const ifaces = os.networkInterfaces();
  for (const name of Object.keys(ifaces))
    for (const iface of ifaces[name])
      if (iface.family === 'IPv4' && !iface.internal) return iface.address;
  return 'localhost';
}

function getPCStats() {
  const cpus    = os.cpus();
  const totalMem = os.totalmem();
  const freeMem  = os.freemem();
  const usedMem  = totalMem - freeMem;
  const avgCpu   = Math.round(
    cpus.map(c => {
      const total = Object.values(c.times).reduce((a,b) => a+b, 0);
      return (1 - c.times.idle / total) * 100;
    }).reduce((a,b) => a+b, 0) / cpus.length
  );
  return {
    cpu: avgCpu,
    ram: {
      used   : Math.round(usedMem/1024/1024/1024*10)/10,
      total  : Math.round(totalMem/1024/1024/1024*10)/10,
      percent: Math.round(usedMem/totalMem*100),
    },
    uptime  : Math.round(os.uptime()/3600*10)/10,
    platform: os.platform(),
    hostname: os.hostname(),
  };
}

// ════════════════════════════════════════════════
// API ENDPOINTS
// ════════════════════════════════════════════════

app.get('/api/info', (req, res) => {
  res.json({ ip: getLocalIP(), port: PORT });
});

app.get('/api/qr', (req, res) => {
  const ip  = getLocalIP();
  const url = `http://${ip}:${PORT}`;
  res.json({ url, qr: null });
});

app.get('/api/stats', (req, res) => {
  res.json(getPCStats());
});

// License status (TV app đọc để hiện cảnh báo)
app.get('/api/license', (req, res) => {
  res.json(licenseState);
});

// Kích hoạt bằng key
app.post('/api/license/activate', async (req, res) => {
  const { key } = req.body;
  if (!key) return res.status(400).json({ success: false, error: 'Thiếu key' });

  const machine_id = getMachineID();
  const result     = await activateLicense(key.trim().toUpperCase(), machine_id);

  if (result.valid) {
    saveLicense({ key: key.trim().toUpperCase(), expires_at: result.expires_at });
    await checkLicense(); // refresh state
    res.json({ success: true, ...result });
  } else {
    res.json({ success: false, error: result.error });
  }
});

// ── PC Power Control API ──────────────────────────
const { exec } = require('child_process');

// Tắt màn hình TV (tắt HDMI output thứ 2) — Windows only
app.post('/api/tv/off', (req, res) => {
  // Dùng NirCmd hoặc PowerShell để tắt display thứ 2
  // Cách 1: tắt toàn bộ màn hình (screen saver black)
  exec('powershell -Command "(Add-Type -MemberDefinition \'[DllImport(\\\"user32.dll\\\")]public static extern int SendMessage(int hWnd,int hMsg,int wParam,int lParam);\' -Name \'W\' -Namespace \'W\');[W.W]::SendMessage(-1,0x0112,0xF170,2)"', (err) => {
    if (err) {
      // Fallback: dùng timeout /t 0 để tắt màn hình
      exec('timeout /t 1 >nul & powershell -command "& {$wsh = New-Object -ComObject WScript.Shell; $wsh.SendKeys(\'.\')}"');
    }
  });
  broadcast({ type: 'tv_power', state: 'off' });
  res.json({ success: true, action: 'tv_off' });
});

// Bật lại màn hình TV (move mouse để wake)
app.post('/api/tv/on', (req, res) => {
  exec('powershell -Command "$wsh=New-Object -ComObject WScript.Shell;$wsh.SendKeys(\' \')"');
  broadcast({ type: 'tv_power', state: 'on' });
  res.json({ success: true, action: 'tv_on' });
});

// PC Sleep
app.post('/api/pc/sleep', (req, res) => {
  res.json({ success: true, action: 'sleep' });
  broadcast({ type: 'pc_power', state: 'sleep' });
  setTimeout(() => {
    exec('rundll32.exe powrprof.dll,SetSuspendState 0,1,0');
  }, 1500);
});

// PC Shutdown
app.post('/api/pc/shutdown', (req, res) => {
  res.json({ success: true, action: 'shutdown' });
  broadcast({ type: 'pc_power', state: 'shutdown' });
  setTimeout(() => {
    exec('shutdown /s /t 10 /c "Tắt máy từ TV Remote"');
  }, 1500);
});

// Huỷ shutdown
app.post('/api/pc/shutdown-cancel', (req, res) => {
  exec('shutdown /a');
  res.json({ success: true, action: 'cancel' });
});

// ── Screen Wall (chặn chuột qua lại 2 màn hình) ──
let screenWallProcess = null;
let screenWallActive  = false;

app.get('/api/wall/status', (req, res) => {
  res.json({ active: screenWallActive });
});

app.post('/api/wall/on', (req, res) => {
  if (screenWallActive) return res.json({ success: true, active: true, note: 'Đã bật rồi' });
  const scriptPath = path.join(__dirname, '..', 'screen_wall.py');
  if (!fs.existsSync(scriptPath)) {
    return res.status(404).json({ success: false, error: 'Không tìm thấy screen_wall.py' });
  }
  screenWallProcess = require('child_process').spawn('python', [scriptPath], {
    detached: false,
    stdio: 'ignore',
  });
  screenWallProcess.on('exit', () => {
    screenWallActive = false;
    screenWallProcess = null;
    broadcast({ type: 'wall_status', active: false });
  });
  screenWallActive = true;
  broadcast({ type: 'wall_status', active: true });
  res.json({ success: true, active: true });
});

app.post('/api/wall/off', (req, res) => {
  if (!screenWallActive || !screenWallProcess) {
    screenWallActive = false;
    return res.json({ success: true, active: false, note: 'Không có tiến trình nào' });
  }
  try {
    // Windows: kill cả cây tiến trình
    exec(`taskkill /PID ${screenWallProcess.pid} /T /F`, () => {});
    screenWallProcess = null;
  } catch(e) {}
  screenWallActive = false;
  broadcast({ type: 'wall_status', active: false });
  res.json({ success: true, active: false });
});

// ════════════════════════════════════════════════
// WEBSOCKET
// ════════════════════════════════════════════════

function broadcast(data, exceptWs = null) {
  const msg = JSON.stringify(data);
  wss.clients.forEach(client => {
    if (client.readyState === 1 && client !== exceptWs) client.send(msg);
  });
}

setInterval(() => {
  broadcast({ type: 'stats', data: getPCStats() });
}, 2000);

// Check license mỗi 6 tiếng
setInterval(checkLicense, 6 * 3600 * 1000);

// Track mobile clients
const mobileClients = new Set();

wss.on('connection', (ws, req) => {
  const ip = req.socket.remoteAddress;
  console.log(`[+] Client kết nối: ${ip}`);
  ws.send(JSON.stringify({ type: 'stats', data: getPCStats() }));
  ws.send(JSON.stringify({ type: 'license', data: licenseState }));

  ws.on('message', msg => {
    try {
      const data = JSON.parse(msg.toString());
      // Đánh dấu client này là mobile
      if (data.type === 'mobile_connected') {
        mobileClients.add(ws);
      }
      broadcast(data, ws);
    } catch(e) {}
  });

  ws.on('close', () => {
    console.log(`[-] Client ngắt kết nối: ${ip}`);
    if (mobileClients.has(ws)) {
      mobileClients.delete(ws);
      // Nếu không còn mobile nào → báo TV hiện QR lại
      if (mobileClients.size === 0) {
        broadcast({ type: 'mobile_disconnected' });
      }
    }
  });
});

// ════════════════════════════════════════════════
// STARTUP
// ════════════════════════════════════════════════

const PORT = 3000;

async function main() {
  // Check license trước khi start
  console.log('\n[License] Đang kiểm tra license...');
  await checkLicense();

  server.listen(PORT, '0.0.0.0', () => {
    const ip = getLocalIP();
    console.log('\n╔══════════════════════════════════════════╗');
    console.log('║        TV DASHBOARD SERVER RUNNING        ║');
    console.log('╠══════════════════════════════════════════╣');
    console.log(`║  📺 TV App  : http://${ip}:${PORT}/tv`);
    console.log(`║  📱 Mobile  : http://${ip}:${PORT}`);
    console.log(`║  🔌 WS      : ws://${ip}:${PORT}`);
    console.log('╠══════════════════════════════════════════╣');

    if (licenseState.valid) {
      console.log(`║  🔑 License : ✅ HỢP LỆ`);
      if (licenseState.days_left) {
        console.log(`║  📅 Hết hạn : còn ${licenseState.days_left} ngày`);
      }
    } else {
      console.log(`║  🔑 License : ❌ ${licenseState.message}`);
      console.log('║  ⚠️  Mở http://localhost:3000 để kích hoạt');
    }

    console.log('╚══════════════════════════════════════════╝\n');
  });
}

main();
